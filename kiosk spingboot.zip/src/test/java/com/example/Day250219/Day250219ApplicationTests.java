package com.example.Day250219;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day250219ApplicationTests {

	@Test
	void contextLoads() {
	}

}
