insert into user_info(phone_number, point) values('010-1111-1111', 3000);
insert into user_info(phone_number, point) values('010-2222-2222', 6000);
insert into user_info(phone_number, point) values('010-3333-3333', 7000);

insert into stamp(user_info_id, coupon_name, amount, period, is_usable) values(1, 'C1', 2, '1', true);
insert into stamp(user_info_id, coupon_name, amount, period, is_usable) values(2, 'C2', 1, '2', true);
insert into stamp(user_info_id, coupon_name, amount, period, is_usable) values(3, 'C1', 3, '1', false);

insert into order_info(item_name, count, price, size, hot_or_ice, topping, etc) values('americano', 1, 3500, 'regular', 'ice', 'no', 'no');
insert into order_info(item_name, count, price, size, hot_or_ice, topping, etc) values('espresso', 1, 3000, 'regular', 'hot', 'no', 'no');
insert into order_info(item_name, count, price, size, hot_or_ice, topping, etc) values('caffe latte', 2, 4500, 'large', 'hot', 'no', 'no');
