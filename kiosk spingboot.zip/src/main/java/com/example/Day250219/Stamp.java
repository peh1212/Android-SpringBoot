package com.example.Day250219;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.jpa.repository.JpaRepository;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@ToString
@Builder
@Entity
public class Stamp {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name="user_info_id")
    private UserInfo userInfo;

    @Column
    private String couponName;
    @Column
    private int amount;
    @Column
    private String period;
    @Column
    private boolean isUsable;
}

interface StampRepo extends JpaRepository<Stamp, Long> {

}

@AllArgsConstructor
@Getter
@Builder
@ToString
class StampDTO {
    private Long userInfoId;
    private String couponName;
    private int amount;
    private String period;
    private boolean isUsable;
}