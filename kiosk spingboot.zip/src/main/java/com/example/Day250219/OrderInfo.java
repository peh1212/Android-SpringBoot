package com.example.Day250219;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.*;
import org.springframework.data.jpa.repository.JpaRepository;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Builder
@ToString
@Entity
public class OrderInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String itemName;
    private int count;
    private int price;
    private String size;
    private String hotOrIce;
    private String topping;
    private String etc;
}

interface OrderInfoRepo extends JpaRepository<OrderInfo, Long> {
}

@AllArgsConstructor
@Getter
@Builder
@ToString
class OrderInfoDTO {
    private String itemName;
    private int count;
    private int price;
    private String size;
    private String hotOrIce;
    private String topping;
    private String etc;
}