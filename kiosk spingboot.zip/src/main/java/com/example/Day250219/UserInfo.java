package com.example.Day250219;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.*;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Builder
@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class UserInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String phoneNumber;
    private int point;
}

interface UserInfoRepo extends JpaRepository<UserInfo, Long> {
    UserInfo findByPhoneNumber(String phoneNumber);
}
// 기본적으로 제공해주는 CURD 외에도 Repository에서 필드명으로 데이터를 찾는 것을 구현할 수 있다.
// findByPhoneNumber, findByPoint 이런식으로
// 더 복잡한것은 쿼리로 할수있다

@AllArgsConstructor
@Getter
@Builder
@ToString
class UserInfoDTO {
    private String phoneNumber;
    private int point;
}

@RestController
class UserInfoRestController {

    @Autowired
    UserInfoRepo userInfoRepo;

    @GetMapping("/api/users")
    List<UserInfo> index() {
        return userInfoRepo.findAll();
    }

    @GetMapping("/api/users2")
    ResponseEntity<List<UserInfo>> index2() {
        return ResponseEntity.status(HttpStatus.OK).body(userInfoRepo.findAll());
    }
    // 위에 @GetMapping("/api/users") 처럼 해도 데이터는 전송되지만
    // ResponseEntity를 사용하면 데이터전송+상태정보까지 알려준다
    // 데이터 전송되는건 body() 부분이고 상태는 status()부분
    // HttpStatus.BAD_REQUEST = 400뜸, OK는 200뜨고 CREATED는 201

    @GetMapping("/api/users/{id}")
    UserInfo getUserById(@PathVariable Long id) {
        return userInfoRepo.findById(id).orElse(null);
    }

    @GetMapping("/api/users/phone/{phoneNumber}")
    UserInfo getUserByPhoneNumber(@PathVariable String phoneNumber) {
        return userInfoRepo.findByPhoneNumber(phoneNumber);
    }


    @PostMapping("/api/users")
    UserInfo postUser(@RequestBody UserInfoDTO userInfoDTO) {
        String phoneNumber = userInfoDTO.getPhoneNumber();
        int point = userInfoDTO.getPoint();
        UserInfo userInfo = new UserInfo(null, phoneNumber, point);
//        UserInfo.builder().phoneNumber(phoneNumber).point(point);
        // builder 사용시 인자 순서 상관X, 인자 안넣어주면 자동으로 null이 들어감
        return userInfoRepo.save(userInfo);
    }

    @PatchMapping("/api/users/{id}")
    UserInfo updateUser(@PathVariable Long id, @RequestBody UserInfoDTO userInfoDTO) {
        String phoneNumber = userInfoDTO.getPhoneNumber();
        int point = userInfoDTO.getPoint();
        UserInfo userInfo = userInfoRepo.findById(id).orElse(null);
        if (phoneNumber != null) userInfo.setPhoneNumber(phoneNumber);
        if (point > 0) userInfo.setPoint(point);
        return userInfoRepo.save(userInfo);
    }

    @DeleteMapping("/api/users/{id}")
    UserInfo deleteUser(@PathVariable Long id) {
        userInfoRepo.deleteById(id);
        return null;
    }
    // id가 다른 데이터와 연결되어있으면 500이 뜨고 딜리트되지않는다.

}