package com.example.Day250219;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day250219Application {

	public static void main(String[] args) {
		SpringApplication.run(Day250219Application.class, args);
	}

}
